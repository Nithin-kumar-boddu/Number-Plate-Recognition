Contents
────────
• Number_plate_Recognition.ipynb   – fully-commented notebook  
• models/best.pt                   – trained YOLOv8 weights  
• requirements.txt                 – reproducible Python package list  

How to reproduce
────────────────
1.  pip install -r requirements.txt
2.  Run Number_Plate_Recognition.ipynb end-to-end (GPU optional).  
    Only Phase 8 performs inference; total runtime ≈ 8 minutes on Colab CPU.

Note
─────
* The detector was originally trained for 25 epochs.  
* The notebook now reloads the stored weights and skips retraining to save time.
